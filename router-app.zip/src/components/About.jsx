import React from "react";

function About(props) {
  return (
    <div>
      <h1>소개</h1>
      <p>이 프로젝트는 리액트 라우터 기초를 실습해보겠습니다.</p>
    </div>
  );
}

export default About;
